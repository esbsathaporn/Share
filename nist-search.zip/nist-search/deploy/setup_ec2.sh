#!/usr/bin/env bash
# setup_ec2.sh
#
# Provisions a fresh Amazon Linux 2023 EC2 instance (sized for t3.nano,
# 2 vCPU / 0.5 GiB RAM, 20 GiB gp3 root volume) to serve the NIST SP 800-53
# control lookup tool as a static site behind nginx.
#
# Usage (run on the instance, as the ec2-user, from the directory that
# contains this repo, e.g. ~/nist-search):
#   chmod +x deploy/setup_ec2.sh
#   sudo ./deploy/setup_ec2.sh
#
# What it does:
#   1. Adds a 1 GiB swap file (t3.nano only has 512 MB RAM; `dnf` and the
#      one-time catalog download/parse are more comfortable with a little
#      headroom).
#   2. Installs nginx and python3 (python3 ships with AL2023 already).
#   3. Runs build_data.py to download the official NIST catalog and
#      generate web/data/controls.json.
#   4. Copies the web/ directory to /usr/share/nginx/html.
#   5. Installs an nginx server block with gzip + static caching.
#   6. Enables and (re)starts nginx.
#
# Safe to re-run: it skips steps that are already done.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run this with sudo: sudo ./deploy/setup_ec2.sh" >&2
  exit 1
fi

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WEB_ROOT="/usr/share/nginx/html"
SWAP_FILE="/swapfile"

echo "== 1/6 swap file =="
if [[ ! -f "$SWAP_FILE" ]]; then
  fallocate -l 1G "$SWAP_FILE" || dd if=/dev/zero of="$SWAP_FILE" bs=1M count=1024
  chmod 600 "$SWAP_FILE"
  mkswap "$SWAP_FILE"
  swapon "$SWAP_FILE"
  grep -q "$SWAP_FILE" /etc/fstab || echo "$SWAP_FILE swap swap defaults 0 0" >> /etc/fstab
  echo "swap file created (1G)"
else
  echo "swap file already present, skipping"
fi

echo "== 2/6 packages =="
dnf -y update
dnf -y install nginx python3

echo "== 3/6 build control catalog =="
mkdir -p "$REPO_DIR/web/data"
python3 "$REPO_DIR/build_data.py" --out "$REPO_DIR/web/data/controls.json"

echo "== 4/6 deploy static files =="
rm -rf "$WEB_ROOT"/*
cp -r "$REPO_DIR"/web/* "$WEB_ROOT"/
chown -R nginx:nginx "$WEB_ROOT"

echo "== 5/6 nginx server block =="
cp "$REPO_DIR/deploy/nginx.conf" /etc/nginx/conf.d/nist-search.conf
# Remove the default welcome server block if present so ours is the only one
if [[ -f /etc/nginx/conf.d/default.conf ]]; then
  rm -f /etc/nginx/conf.d/default.conf
fi
nginx -t

echo "== 6/6 enable + start nginx =="
systemctl enable nginx
systemctl restart nginx

echo
echo "Done. The tool should now be reachable at:"
echo "  http://<this-instance-public-ip>/"
echo
echo "To refresh the control catalog later (e.g. after a NIST update), run:"
echo "  sudo python3 $REPO_DIR/build_data.py --out $WEB_ROOT/data/controls.json"
