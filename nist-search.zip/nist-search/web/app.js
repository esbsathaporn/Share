(function () {
  "use strict";

  var DATA_URL = "data/controls.json";

  var els = {
    status: document.getElementById("status"),
    q: document.getElementById("q"),
    clear: document.getElementById("clear"),
    onlyBaseline: document.getElementById("onlyBaseline"),
    hideEnh: document.getElementById("hideEnh"),
    familySelect: document.getElementById("familySelect"),
    resultsMeta: document.getElementById("resultsMeta"),
    results: document.getElementById("results"),
    overlay: document.getElementById("overlay"),
    detailPanel: document.getElementById("detailPanel"),
    detailContent: document.getElementById("detailContent"),
    detailClose: document.getElementById("detailClose"),
    genMeta: document.getElementById("genMeta"),
  };

  var STATE = {
    controls: [],
    byId: {},
    enhByParent: {},
  };

  // Mirrors build_data.py's search_key(): collapse to letters + digits,
  // uppercase, strip leading zeros on numeric runs. "AC-01" and "ac 1"
  // both become "AC1".
  function searchKey(raw) {
    var out = [];
    var numBuf = "";
    function flush() {
      if (numBuf) {
        out.push(String(parseInt(numBuf, 10)));
        numBuf = "";
      }
    }
    raw = String(raw || "");
    for (var i = 0; i < raw.length; i++) {
      var ch = raw[i];
      if (ch >= "0" && ch <= "9") {
        numBuf += ch;
      } else {
        flush();
        if (/[a-zA-Z]/.test(ch)) out.push(ch.toUpperCase());
      }
    }
    flush();
    return out.join("");
  }

  function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function highlight(text, needle) {
    if (!needle) return escapeHtml(text);
    var idx = text.toLowerCase().indexOf(needle.toLowerCase());
    if (idx === -1) return escapeHtml(text);
    return (
      escapeHtml(text.slice(0, idx)) +
      "<mark>" + escapeHtml(text.slice(idx, idx + needle.length)) + "</mark>" +
      escapeHtml(text.slice(idx + needle.length))
    );
  }

  function snippet(control) {
    return control.statement || control.discussion || "";
  }

  function loadData() {
    fetch(DATA_URL, { cache: "force-cache" })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        STATE.controls = data.controls || [];
        STATE.controls.forEach(function (c) {
          STATE.byId[c.id] = c;
          if (c.is_enhancement && c.parent) {
            (STATE.enhByParent[c.parent] = STATE.enhByParent[c.parent] || []).push(c);
          }
        });

        var families = data.families || [];
        families.forEach(function (f) {
          var opt = document.createElement("option");
          opt.value = f.id;
          opt.textContent = f.id + " \u2014 " + f.title;
          els.familySelect.appendChild(opt);
        });

        els.status.textContent = data.control_count + " controls loaded";
        els.status.classList.add("ready");
        if (data.generated_from) {
          els.genMeta.textContent = " Loaded " + data.control_count + " controls.";
        }
        render();
      })
      .catch(function (err) {
        els.status.textContent = "failed to load catalog";
        els.results.innerHTML =
          '<div class="empty">Could not load data/controls.json.<br>Run build_data.py on the server, then reload this page.<br><span style="color:var(--text-faint);font-family:var(--mono);font-size:11px">' +
          escapeHtml(err.message) +
          "</span></div>";
      });
  }

  function currentQuery() {
    return els.q.value.trim();
  }

  function matches(control, query, key) {
    if (!query) return true;
    if (key && control.key.indexOf(key) === 0) return true; // ID prefix match
    if (key && control.key.indexOf(key) !== -1) return true; // ID contains
    var q = query.toLowerCase();
    if (control.title.toLowerCase().indexOf(q) !== -1) return true;
    if (control.statement && control.statement.toLowerCase().indexOf(q) !== -1) return true;
    if (control.discussion && control.discussion.toLowerCase().indexOf(q) !== -1) return true;
    return false;
  }

  function render() {
    var query = currentQuery();
    var key = query ? searchKey(query) : "";
    var onlyBaseline = els.onlyBaseline.checked;
    var hideEnh = els.hideEnh.checked;
    var family = els.familySelect.value;

    els.clear.classList.toggle("show", !!query);

    var list = STATE.controls.filter(function (c) {
      if (onlyBaseline && !c.config_baseline_relevant) return false;
      if (hideEnh && c.is_enhancement) return false;
      if (family && c.family !== family) return false;
      return matches(c, query, key);
    });

    // Rank exact / prefix ID matches first when there's a query
    if (query) {
      list.sort(function (a, b) {
        var aScore = a.key === key ? 0 : a.key.indexOf(key) === 0 ? 1 : 2;
        var bScore = b.key === key ? 0 : b.key.indexOf(key) === 0 ? 1 : 2;
        if (aScore !== bScore) return aScore - bScore;
        return a.key.localeCompare(b.key);
      });
    }

    var LIMIT = 150;
    var shown = list.slice(0, LIMIT);

    els.resultsMeta.textContent = query || onlyBaseline || family || hideEnh
      ? list.length + " match" + (list.length === 1 ? "" : "es") +
        (list.length > LIMIT ? " (showing first " + LIMIT + ")" : "")
      : list.length + " controls \u2014 start typing a control ID (e.g. AC-01) or a keyword";

    if (shown.length === 0) {
      els.results.innerHTML = '<div class="empty">No controls match. Try a control ID like <b>CM-6</b> or a keyword like <b>logging</b>.</div>';
      return;
    }

    var frag = document.createDocumentFragment();
    shown.forEach(function (c) {
      frag.appendChild(buildRow(c, query));
    });
    els.results.innerHTML = "";
    els.results.appendChild(frag);
  }

  function buildRow(c, query) {
    var row = document.createElement("div");
    row.className = "row";
    row.tabIndex = 0;
    row.setAttribute("role", "button");

    var idEl = document.createElement("div");
    idEl.className = "row-id" + (c.is_enhancement ? " is-enh" : "");
    idEl.textContent = c.id;

    var main = document.createElement("div");
    main.className = "row-main";
    var titleEl = document.createElement("div");
    titleEl.className = "row-title";
    titleEl.innerHTML = highlight(c.title, query);
    var snipEl = document.createElement("div");
    snipEl.className = "row-snippet";
    snipEl.innerHTML = highlight(snippet(c), query && query.length > 2 ? query : "");
    main.appendChild(titleEl);
    main.appendChild(snipEl);

    var tags = document.createElement("div");
    tags.className = "row-tags";
    var famTag = document.createElement("span");
    famTag.className = "tag";
    famTag.textContent = c.family;
    tags.appendChild(famTag);
    if (c.config_baseline_relevant) {
      var relTag = document.createElement("span");
      relTag.className = "tag relevant";
      relTag.textContent = "baseline";
      tags.appendChild(relTag);
    }

    row.appendChild(idEl);
    row.appendChild(main);
    row.appendChild(tags);

    row.addEventListener("click", function () {
      openDetail(c.id);
    });
    row.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        openDetail(c.id);
      }
    });

    return row;
  }

  function openDetail(id) {
    var c = STATE.byId[id];
    if (!c) return;

    var html = "";
    html += '<div class="d-id">' + escapeHtml(c.id) + "</div>";
    html += '<div class="d-title">' + escapeHtml(c.title) + "</div>";
    html += '<div class="d-family">' + escapeHtml(c.family) + " \u2014 " + escapeHtml(c.family_title);
    if (c.is_enhancement && c.parent) {
      html += ' &middot; enhancement of <a href="#" data-goto="' + escapeHtml(c.parent) + '">' + escapeHtml(c.parent) + "</a>";
    }
    if (c.config_baseline_relevant) {
      html += ' &middot; <span style="color:var(--accent)">relevant to configuration baseline</span>';
    }
    html += "</div>";

    if (c.statement) {
      html += '<div class="d-block"><h3>Control statement</h3><p>' + escapeHtml(c.statement) + "</p></div>";
    }
    if (c.discussion) {
      html += '<div class="d-block"><h3>Discussion / guidance</h3><p>' + escapeHtml(c.discussion) + "</p></div>";
    }

    var children = STATE.enhByParent[c.id];
    if (children && children.length) {
      html += '<div class="d-block"><h3>Control enhancements</h3><div class="d-enh-list">';
      children
        .slice()
        .sort(function (a, b) { return a.key.localeCompare(b.key); })
        .forEach(function (ch) {
          html += '<div class="d-enh-item" data-goto="' + escapeHtml(ch.id) + '">' + escapeHtml(ch.id) + " \u2014 " + escapeHtml(ch.title) + "</div>";
        });
      html += "</div></div>";
    }

    els.detailContent.innerHTML = html;
    els.overlay.hidden = false;
    els.detailPanel.scrollTop = 0;

    els.detailContent.querySelectorAll("[data-goto]").forEach(function (node) {
      node.addEventListener("click", function (e) {
        e.preventDefault();
        openDetail(node.getAttribute("data-goto"));
      });
    });
  }

  function closeDetail() {
    els.overlay.hidden = true;
  }

  els.detailClose.addEventListener("click", closeDetail);
  els.overlay.addEventListener("click", function (e) {
    if (e.target === els.overlay) closeDetail();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && !els.overlay.hidden) closeDetail();
  });

  var debounceTimer = null;
  els.q.addEventListener("input", function () {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(render, 60);
  });
  els.clear.addEventListener("click", function () {
    els.q.value = "";
    els.q.focus();
    render();
  });
  els.onlyBaseline.addEventListener("change", render);
  els.hideEnh.addEventListener("change", render);
  els.familySelect.addEventListener("change", render);

  loadData();
})();
