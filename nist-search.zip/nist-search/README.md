# NIST SP 800-53 Control Lookup

A small, fast web app to look up NIST SP 800-53 Rev 5 controls by ID
(`AC-01`, `CM-6`, `SC-7(4)` ...) or by keyword. Built to run comfortably on
a single **t3.nano** EC2 instance (2 vCPU burstable, 0.5 GiB RAM) with a
**20 GB** root volume.

## Why this fits on a t3.nano

There is no application server and no database. `build_data.py` downloads
NIST's own official machine-readable catalog once and turns it into a
single `controls.json` file (a few MB). At runtime, **nginx only serves
static files** (HTML/CSS/JS/JSON) — the search itself runs in the visitor's
browser. That means request handling costs almost no CPU or RAM no matter
how many people search at once, which is the right shape for the smallest
EC2 instance class.

```
                 ┌───────────────────────────┐
  browser  ─────▶│ nginx (static files only) │
  (search runs    │  index.html / app.js /    │
   client-side)   │  style.css / controls.json│
                 └───────────────────────────┘
                     t3.nano · 20 GB gp3 volume
```

## What's in this folder

```
nist-search/
├── build_data.py        # downloads the NIST catalog -> web/data/controls.json
├── web/                  # the static site (deployed as-is to nginx)
│   ├── index.html
│   ├── style.css
│   └── app.js
├── deploy/
│   ├── setup_ec2.sh      # one-shot provisioning script for the instance
│   └── nginx.conf         # nginx server block
└── README.md
```

Data source: the official NIST SP 800-53 Rev 5 catalog published in OSCAL
JSON format by NIST at
[usnistgov/oscal-content](https://github.com/usnistgov/oscal-content)
(a public-domain US government work). `build_data.py` downloads it directly
from GitHub, so the app always ships with NIST's authoritative control text
rather than a hand-copied subset.

Each control is tagged `config_baseline_relevant: true/false` using a
general heuristic (families **AC, AU, CM, IA, MA, SC, SI**, the ones most
directly tied to a technical configuration baseline for routers, switches,
firewalls, and cloud services). This is a helpful default filter, not a
substitute for a reviewed baseline — see "Adding your own relevance
ratings" below.

---

## 1. Launch the EC2 instance

In the AWS Console (EC2 → Launch instance):

| Setting | Value |
|---|---|
| AMI | Amazon Linux 2023 |
| Instance type | t3.nano |
| Key pair | choose/create one for SSH |
| Network | any VPC/subnet with a public IP (or use an existing one behind a load balancer) |
| Storage | 20 GiB, gp3 |
| Security group | inbound: SSH (22) from your IP only; HTTP (80) from anywhere (0.0.0.0/0); HTTPS (443) from anywhere if you plan to add TLS |

Launch it and note its public IP or public DNS name.

## 2. Upload this folder to the instance

From your machine, zip this folder if it isn't already, then:

```bash
scp -i /path/to/your-key.pem nist-search.zip ec2-user@<instance-public-ip>:~
ssh -i /path/to/your-key.pem ec2-user@<instance-public-ip>
unzip nist-search.zip
cd nist-search
```

## 3. Run the setup script

```bash
chmod +x deploy/setup_ec2.sh
sudo ./deploy/setup_ec2.sh
```

This adds a 1 GB swap file, installs nginx, downloads and converts the NIST
catalog, deploys the static site, and starts nginx. It takes a couple of
minutes (mostly `dnf update`).

## 4. Verify

Open `http://<instance-public-ip>/` in a browser. Try searching `AC-01` or
`configuration settings`.

If it doesn't load, check:

```bash
sudo systemctl status nginx
sudo nginx -t
curl -I http://localhost/data/controls.json
```

## 5. (Optional) put it behind a domain + HTTPS

If you have a domain pointed at the instance:

```bash
sudo dnf -y install python3-certbot-nginx
sudo certbot --nginx -d your-domain.example
```

Certbot will edit the nginx config to add a 443 listener and auto-renewing
TLS certificate.

## 6. Refreshing the catalog later

NIST updates the catalog occasionally (e.g. patch releases). To pull the
latest version:

```bash
sudo python3 ~/nist-search/build_data.py --out /usr/share/nginx/html/data/controls.json
```

You can put that in a monthly cron job if you want it to stay current
automatically:

```bash
echo "0 3 1 * * root python3 /home/ec2-user/nist-search/build_data.py --out /usr/share/nginx/html/data/controls.json" | sudo tee /etc/cron.d/nist-catalog-refresh
```

---

## Adding your own relevance ratings

If you already have a reviewed configuration-baseline spreadsheet (relevance
rating per control, explanatory notes, etc.), the cleanest way to bring that
into this tool is to merge it into `controls.json` as extra fields (e.g.
`relevance`, `notes`) and extend `app.js`/`style.css` to display them. Share
the spreadsheet and its column layout and this can be scripted as a
`merge_baseline.py` step that runs right after `build_data.py`.

## Local testing before you deploy

You can preview the site on any machine with Python and internet access:

```bash
python3 build_data.py --out web/data/controls.json
cd web && python3 -m http.server 8080
# open http://localhost:8080
```
