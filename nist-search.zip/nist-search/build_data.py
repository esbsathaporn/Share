#!/usr/bin/env python3
"""
build_data.py

Downloads the official NIST SP 800-53 Revision 5 control catalog (published by
NIST in OSCAL JSON format, public domain) and converts it into a single
compact controls.json file used by the static search front end.

Source catalog:
  https://github.com/usnistgov/oscal-content
  (nist.gov/SP800-53/rev5/json/NIST_SP-800-53_rev5_catalog.json)

Usage:
  python3 build_data.py [--out OUTPUT_PATH]

Requires only the Python standard library (urllib, json) so it runs on a
bare EC2 instance without installing extra packages. Run this once during
deployment (or again later to refresh the catalog) with a machine that has
outbound internet access.
"""

import argparse
import json
import sys
import urllib.request

CATALOG_URL = (
    "https://raw.githubusercontent.com/usnistgov/oscal-content/main/"
    "nist.gov/SP800-53/rev5/json/NIST_SP-800-53_rev5_catalog.json"
)

# Families whose controls are the most directly relevant to a technical
# configuration baseline for cloud / network devices (router, switch,
# firewall, hypervisor, etc). This is a general heuristic tag only -- if you
# have your own relevance ratings (e.g. from a reviewed Excel baseline),
# merge them in separately; this tag is just a helpful default filter.
BASELINE_RELEVANT_FAMILIES = {
    "AC",  # Access Control
    "AU",  # Audit and Accountability
    "CM",  # Configuration Management
    "IA",  # Identification and Authentication
    "SC",  # System and Communications Protection
    "SI",  # System and Information Integrity
    "MA",  # Maintenance
}


def fetch_catalog(url: str) -> dict:
    print(f"Downloading catalog from {url} ...", file=sys.stderr)
    req = urllib.request.Request(url, headers={"User-Agent": "nist-control-search/1.0"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        raw = resp.read()
    print(f"Downloaded {len(raw) / 1024:.0f} KB", file=sys.stderr)
    return json.loads(raw)


def collect_prose(parts, label_prefix=""):
    """Recursively flatten an OSCAL 'parts' list into readable text lines."""
    lines = []
    if not parts:
        return lines
    for part in parts:
        if part.get("name") not in ("statement", "item", "guidance", "objective"):
            continue
        label = ""
        for prop in part.get("props", []) or []:
            if prop.get("name") == "label":
                label = prop.get("value", "")
                break
        prose = part.get("prose", "")
        if prose:
            prefix = f"{label} " if label else ""
            lines.append(f"{prefix}{prose}".strip())
        if part.get("parts"):
            lines.extend(collect_prose(part["parts"]))
    return lines


def extract_statement(control) -> str:
    for part in control.get("parts", []) or []:
        if part.get("name") == "statement":
            lines = collect_prose([part])
            return "\n".join(lines)
    return ""


def extract_discussion(control) -> str:
    texts = []
    for part in control.get("parts", []) or []:
        if part.get("name") in ("guidance",):
            if part.get("prose"):
                texts.append(part["prose"])
    return "\n\n".join(texts)


def normalize_id(raw_id: str) -> str:
    """'ac-2.1' -> 'AC-2(1)', 'ac-1' -> 'AC-1'"""
    raw_id = raw_id.upper()
    if "." in raw_id:
        base, enh = raw_id.split(".", 1)
        return f"{base}({enh})"
    return raw_id


def search_key(display_id: str) -> str:
    """Collapse an id down to just letters+digits, uppercase, no leading
    zeros, e.g. 'AC-01' -> 'AC1', 'AC-2(1)' -> 'AC21'. Used for lenient
    matching so 'ac01', 'AC-1', 'ac 1' all find the same control."""
    out = []
    num_buf = ""

    def flush():
        nonlocal num_buf
        if num_buf:
            out.append(str(int(num_buf)))
            num_buf = ""

    for ch in display_id:
        if ch.isdigit():
            num_buf += ch
        else:
            flush()
            if ch.isalpha():
                out.append(ch.upper())
    flush()
    return "".join(out)


def walk_controls(controls, family_id, family_title, parent_id=None):
    items = []
    for control in controls or []:
        cid = control.get("id", "")
        display_id = normalize_id(cid)
        title = control.get("title", "")
        withdrawn = any(
            p.get("name") == "status" and p.get("value") == "withdrawn"
            for p in control.get("props", []) or []
        )
        if not withdrawn:
            items.append(
                {
                    "id": display_id,
                    "key": search_key(display_id),
                    "title": title,
                    "family": family_id,
                    "family_title": family_title,
                    "is_enhancement": parent_id is not None,
                    "parent": parent_id,
                    "statement": extract_statement(control),
                    "discussion": extract_discussion(control),
                    "config_baseline_relevant": family_id in BASELINE_RELEVANT_FAMILIES,
                }
            )
        # Enhancements are nested as sub "controls"
        if control.get("controls"):
            items.extend(
                walk_controls(control["controls"], family_id, family_title, parent_id=display_id)
            )
    return items


def build(catalog: dict) -> list:
    all_items = []
    groups = catalog.get("catalog", {}).get("groups", [])
    for group in groups:
        family_id = (group.get("id") or "").upper()
        family_title = group.get("title", "")
        all_items.extend(walk_controls(group.get("controls", []), family_id, family_title))
    return all_items


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="web/data/controls.json")
    parser.add_argument("--url", default=CATALOG_URL)
    args = parser.parse_args()

    catalog = fetch_catalog(args.url)
    items = build(catalog)
    items.sort(key=lambda x: (x["family"], x["key"]))

    families = {}
    for item in items:
        families.setdefault(item["family"], item["family_title"])
    family_list = [{"id": k, "title": v} for k, v in sorted(families.items())]

    out_data = {
        "generated_from": args.url,
        "control_count": len(items),
        "families": family_list,
        "controls": items,
    }

    import os

    os.makedirs(os.path.dirname(args.out), exist_ok=True) if os.path.dirname(args.out) else None
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out_data, f, ensure_ascii=False, separators=(",", ":"))

    print(f"Wrote {len(items)} controls across {len(family_list)} families to {args.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
